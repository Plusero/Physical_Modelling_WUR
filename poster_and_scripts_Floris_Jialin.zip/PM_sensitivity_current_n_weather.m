
%% Calculation of cable metal part
%lambda of cable material, W/m/K
lambda_c=390;
%density of cable material, kg/m3
rho_c=8960;
%thermal capacity of cable material, J/kg/K
cp_c=390;
%current in cable, A
%I=500;
%copper resisitvitiy, Ohm*m
resistivity_c=1.68*10^-8;
%radius of cable cross section, m
r=0.013*0.5;
%cross sectional area of cable, m2
A=pi*r^2;
%Resistance per volume, Ohm m
%R=resisitvity* length/A
resistivity_vol=resistivity_c/A^2;
%constant c for cable
c_c=lambda_c/(rho_c*cp_c);


%% Calculation of cable insulation
%thermal conductivity, W/m/K
lambda_i=0.27;
%heat capacity insulation material, J/kg/K
cp_i= 2000;
%density of insulation material, kg/m3
rho_i=920;
%C factor for insulation material
c_i=lambda_i/(rho_i*cp_i);

%% Heat Transfer Coeffient for boundary
%lambda of air, W/m/K
lambda_a=0.59;
%dynamic viscosity of air, N s m-2
mu_a=0.6513*10^-3;
%thermal capacity air,  J/kg/K
cp_a=4200;
%density air, kg/m3
rho_a=1.3;
%velocity of air, m/s
vel_a=1;

%thickness of insulation, m
global th
th=0.013;
%Pr number
pr_a= (mu_a*cp_a)/lambda_a;
%Reynolds number
re_a=(rho_a*vel_a*2*r)/mu_a;
%nusselt number laminar component
nu_lam=0.664*re_a^0.5*pr_a^(1/3);
alpha_ca=nu_lam/((2*r)/lambda_a);
global alpha
alpha=alpha_ca;


C1 = [1
    0
    0
    r];

C2 = [1
    0
    0
    (r+th)];

%create geometry
gd = [C1, C2];
ns = char('C1', 'C2');
ns=ns';
sf = 'C1+C2';
[dl,bt] = decsg(gd,sf,ns);
xlim([-1.5,1.5])

axis equal
%create model which is container
model=createpde()
geometryFromEdges(model,dl);
%apply Neumann boundary condition
applyBoundaryCondition(model,"neumann", ...
                             "Edge",[5:8],...
                             "g",@bcfuncN);
%sets initial conditions                         
setInitialConditions(model, 29.9);
%generate and plot mesh
generateMesh(model,"Hmax",0.001);
pdegplot(model,'FaceLabels', "on", 'EdgeLabels',"on");
%coefficients for insulation material
specifyCoefficients(model,"m",0,"d",0,"c",c_i, ...
                          "a",0,"f",0, "Face",2); 

%number of currents to compute
n=10;
%make list of currents to find maxT for
currentlist=linspace(0, 2500, n);
%empty array to append maxt to
temps=zeros();
for I = currentlist
    %constant f for cable
    f_c=I^2*resistivity_vol/(cp_c*rho_c);
    %if d set to zero, steady state
    %c=-lambda/(cp*rho), d=1, m=0, a=0, f=I^2*R/(cp*rho)
    specifyCoefficients(model,"m",0,"d",0,"c",c_c, ...
                          "a",0,"f",f_c, "Face",1);
    results = solvepde(model);
    u=results.NodalSolution;
    %finds index and value of max temperature
    [maxTemperature, maxIndex] = max(u(:));
    temps = horzcat(temps, maxTemperature);
end

xlim([0, (max(currentlist)+100)]);
ylim([(min(temps(2:end))-5), (max(temps)+5)]);

axis square
scatter(currentlist, temps(2:end),  'Marker', 'o', 'MarkerFaceColor', 'red', 'MarkerEdgeColor', 'black')
hold on;
scatter(currentlist, tempw(2:end),  'Marker', 'o', 'MarkerFaceColor', 'blue', 'MarkerEdgeColor', 'black')
hline = refline([0 90]);
hline.Color = 'r';
legend('Summer', 'Winter', 'T limit', 'Location', 'southeast', 'FontSize', 12)
xlabel('Current (A)');
ylabel('Temperature (C^{\circ})');
title('Ampacity');


    
%function for Neumann boundary condition                         
function bc = bcfuncN(location,state);
    %Convection term
    global alpha
    Ta=30;
    global th
    bc = alpha*(state.u-Ta) ;
    %scatter(location.x,location.y,"filled","red");
end


