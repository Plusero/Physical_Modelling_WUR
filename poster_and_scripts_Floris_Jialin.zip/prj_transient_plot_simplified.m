clc;
clear all;
clf;
load transient.mat
time = 1:size(u, 2);
t_step=10;
maxValues = max(u, [], 1);
x=[1.6 5.2 17.2]
y=[150 400 1087]
labels = {'XLPE Degradation \newline (1.6,150)','  \leftarrow XLPE Decompostion(5.2,400)',' \leftarrow Copper Melt(17,2,1087)'};
 
plot(time/t_step, maxValues,'-','LineWidth',2);
hold on 
scatter(x,y,"filled")
text(2,100,'XLPE Degradation \newline t=1.6')
text(6.5,400,'XLPE Decompostion \newline t=5.2')
text(18.5,1087,'Cu Melting Point \newline t=17.2')
% text(x,y,labels,'left')
xlim([0 25])
xlabel('$\textrm{Time(s)}$','interpreter','latex');
ylabel('$\textrm{Copper Temperature} (^{\circ}C)$','interpreter','latex');
title('\textrm{Copper Temperature - Time}','interpreter','latex');

